package com.InventoryAnalysis.Model;

public class SalesDetails {

}
