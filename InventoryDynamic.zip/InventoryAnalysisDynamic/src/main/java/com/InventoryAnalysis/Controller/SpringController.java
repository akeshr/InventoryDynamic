package com.InventoryAnalysis.Controller;

public class SpringController {
	
	

}
